#include <stdio.h>
#include <stdlib.h>
#include "Deque.h"





typedef struct _node
{
	Data data;
	struct _node * next;
	struct _node * prev;
} Node;

typedef struct _dlDeque
{
	Node * head;
	Node * tail;
} Deque;



void DequeInit(Deque * pdeq){
	pdeq->head = NULL;
	pdeq->tail = NULL;
}
int DQIsEmpty(Deque * pdeq){
	if(pdeq->head == pdeq->tail){
		return TRUE;
	}
	return FALSE;
}

void DQAddFirst(Deque * pdeq, Data data){
	Node * newNode = (Node*)malloc(sizeof(Node));
	newNode->data = data;
	newNode->prev = pdeq->head;
	// ù��°�϶�
	if(DQIsEmpty) {
		pdeq->tail = newNode;
	}else{
		pdeq->head->prev = newNode;
	}
	newNode->prev = NULL;
	pdeq->head = newNode;
}

void DQAddLast(Deque * pdeq, Data data){
Node * newNode = (Node*)malloc(sizeof(Node));
	newNode->data = data;
	// ù��°�϶�
	if(DQIsEmpty) {
		pdeq->head = newNode;
		pdeq->tail = newNode;
	}else{
		newNode->prev = pdeq->head;
		pdeq->head->next = newNode;
		pdeq->head = newNode;
	}	
}

Data DQRemoveFirst(Deque * pdeq);
Data DQRemoveLast(Deque * pdeq);

Data DQGetFirst(Deque * pdeq);
Data DQGetLast(Deque * pdeq);
